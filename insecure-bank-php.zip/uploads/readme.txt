Nesta pasta vão ficar os ficheiros enviados pelos utilizadores para o website
